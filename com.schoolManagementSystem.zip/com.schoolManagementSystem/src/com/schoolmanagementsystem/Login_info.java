package com.schoolmanagementsystem;

public class Login_info extends javax.swing.JFrame {

    public Login_info() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelHomeBG = new javax.swing.JPanel();
        jPanelHomeHeader = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1920, 1030));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanelHomeBG.setBackground(new java.awt.Color(255, 255, 255));
        jPanelHomeBG.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanelHomeBG.setMinimumSize(new java.awt.Dimension(1920, 1080));
        jPanelHomeBG.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanelHomeHeader.setBackground(new java.awt.Color(252, 235, 183));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/schoolmanagementsystem/images/icons8_lock_48px.png"))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel2.setText("Login");

        javax.swing.GroupLayout jPanelHomeHeaderLayout = new javax.swing.GroupLayout(jPanelHomeHeader);
        jPanelHomeHeader.setLayout(jPanelHomeHeaderLayout);
        jPanelHomeHeaderLayout.setHorizontalGroup(
            jPanelHomeHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelHomeHeaderLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addGap(0, 881, Short.MAX_VALUE))
        );
        jPanelHomeHeaderLayout.setVerticalGroup(
            jPanelHomeHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelHomeHeaderLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanelHomeHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel1))
                .addContainerGap(38, Short.MAX_VALUE))
        );

        jPanelHomeBG.add(jPanelHomeHeader, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        getContentPane().add(jPanelHomeBG, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1030, 700));

        getAccessibleContext().setAccessibleParent(this);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login_info().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanelHomeBG;
    private javax.swing.JPanel jPanelHomeHeader;
    // End of variables declaration//GEN-END:variables
}
