package com.schoolmanagementsystem;

import javax.swing.JPanel;

public class Home extends javax.swing.JFrame {

    public Home() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelBG = new javax.swing.JPanel();
        jPanelHeader = new javax.swing.JPanel();
        tagline = new javax.swing.JLabel();
        logo = new javax.swing.JLabel();
        jpanelHome = new javax.swing.JPanel();
        homeIcon = new javax.swing.JLabel();
        homeTitle = new javax.swing.JLabel();
        jPanelStudent = new javax.swing.JPanel();
        userIcon = new javax.swing.JLabel();
        studentTitle = new javax.swing.JLabel();
        jPanelTimeTable = new javax.swing.JPanel();
        timeTableIcon = new javax.swing.JLabel();
        timeTableTitle = new javax.swing.JLabel();
        jPanelSettings = new javax.swing.JPanel();
        settingsIcon = new javax.swing.JLabel();
        settingsTitle = new javax.swing.JLabel();
        jPanelClasses = new javax.swing.JPanel();
        classesIcon = new javax.swing.JLabel();
        classesTitle = new javax.swing.JLabel();
        jPanelUpdate = new javax.swing.JPanel();
        updateIcon = new javax.swing.JLabel();
        updateTitle = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(906, 750));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanelBG.setBackground(new java.awt.Color(255, 255, 255));
        jPanelBG.setMinimumSize(new java.awt.Dimension(910, 750));
        jPanelBG.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanelHeader.setBackground(new java.awt.Color(236, 194, 42));

        tagline.setText("School Management System ");

        logo.setFont(new java.awt.Font("Vivaldi", 1, 36)); // NOI18N
        logo.setText("HappyDesk");

        javax.swing.GroupLayout jPanelHeaderLayout = new javax.swing.GroupLayout(jPanelHeader);
        jPanelHeader.setLayout(jPanelHeaderLayout);
        jPanelHeaderLayout.setHorizontalGroup(
            jPanelHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelHeaderLayout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(tagline, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(634, Short.MAX_VALUE))
            .addGroup(jPanelHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanelHeaderLayout.createSequentialGroup()
                    .addGap(38, 38, 38)
                    .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(628, Short.MAX_VALUE)))
        );
        jPanelHeaderLayout.setVerticalGroup(
            jPanelHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelHeaderLayout.createSequentialGroup()
                .addContainerGap(84, Short.MAX_VALUE)
                .addComponent(tagline)
                .addGap(60, 60, 60))
            .addGroup(jPanelHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanelHeaderLayout.createSequentialGroup()
                    .addGap(39, 39, 39)
                    .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(66, Short.MAX_VALUE)))
        );

        jPanelBG.add(jPanelHeader, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 910, 160));

        jpanelHome.setBackground(new java.awt.Color(228, 226, 226));
        jpanelHome.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jpanelHomeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jpanelHomeMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jpanelHomeMousePressed(evt);
            }
        });

        homeIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/schoolmanagementsystem/images/icons8_lock_48px.png"))); // NOI18N

        homeTitle.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        homeTitle.setForeground(new java.awt.Color(51, 51, 51));
        homeTitle.setText("Login");
        homeTitle.setToolTipText("");

        javax.swing.GroupLayout jpanelHomeLayout = new javax.swing.GroupLayout(jpanelHome);
        jpanelHome.setLayout(jpanelHomeLayout);
        jpanelHomeLayout.setHorizontalGroup(
            jpanelHomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpanelHomeLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jpanelHomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(homeTitle)
                    .addComponent(homeIcon))
                .addGap(45, 45, 45))
        );
        jpanelHomeLayout.setVerticalGroup(
            jpanelHomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpanelHomeLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(homeIcon)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(homeTitle)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanelBG.add(jpanelHome, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 270, 150, 140));

        jPanelStudent.setBackground(new java.awt.Color(228, 226, 226));
        jPanelStudent.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanelStudentMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanelStudentMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jPanelStudentMousePressed(evt);
            }
        });

        userIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/schoolmanagementsystem/images/icons8_User_Menu_Female_48px_1.png"))); // NOI18N

        studentTitle.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        studentTitle.setText("Student");
        studentTitle.setToolTipText("");

        javax.swing.GroupLayout jPanelStudentLayout = new javax.swing.GroupLayout(jPanelStudent);
        jPanelStudent.setLayout(jPanelStudentLayout);
        jPanelStudentLayout.setHorizontalGroup(
            jPanelStudentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelStudentLayout.createSequentialGroup()
                .addContainerGap(44, Short.MAX_VALUE)
                .addGroup(jPanelStudentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(studentTitle)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelStudentLayout.createSequentialGroup()
                        .addComponent(userIcon)
                        .addGap(8, 8, 8)))
                .addGap(45, 45, 45))
        );
        jPanelStudentLayout.setVerticalGroup(
            jPanelStudentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelStudentLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(userIcon)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(studentTitle)
                .addContainerGap(33, Short.MAX_VALUE))
        );

        jPanelBG.add(jPanelStudent, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 270, -1, -1));

        jPanelTimeTable.setBackground(new java.awt.Color(228, 226, 226));
        jPanelTimeTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanelTimeTableMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanelTimeTableMouseExited(evt);
            }
        });

        timeTableIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/schoolmanagementsystem/images/icons8_training_48px.png"))); // NOI18N

        timeTableTitle.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        timeTableTitle.setText("TimeTable");
        timeTableTitle.setToolTipText("");

        javax.swing.GroupLayout jPanelTimeTableLayout = new javax.swing.GroupLayout(jPanelTimeTable);
        jPanelTimeTable.setLayout(jPanelTimeTableLayout);
        jPanelTimeTableLayout.setHorizontalGroup(
            jPanelTimeTableLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelTimeTableLayout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(timeTableTitle)
                .addContainerGap(30, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelTimeTableLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(timeTableIcon)
                .addGap(45, 45, 45))
        );
        jPanelTimeTableLayout.setVerticalGroup(
            jPanelTimeTableLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelTimeTableLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(timeTableIcon)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(timeTableTitle)
                .addContainerGap(33, Short.MAX_VALUE))
        );

        jPanelBG.add(jPanelTimeTable, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 270, 150, -1));

        jPanelSettings.setBackground(new java.awt.Color(228, 226, 226));
        jPanelSettings.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanelSettingsMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanelSettingsMouseExited(evt);
            }
        });

        settingsIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/schoolmanagementsystem/images/icons8_settings_48px.png"))); // NOI18N

        settingsTitle.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        settingsTitle.setText("Settings");
        settingsTitle.setToolTipText("");

        javax.swing.GroupLayout jPanelSettingsLayout = new javax.swing.GroupLayout(jPanelSettings);
        jPanelSettings.setLayout(jPanelSettingsLayout);
        jPanelSettingsLayout.setHorizontalGroup(
            jPanelSettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelSettingsLayout.createSequentialGroup()
                .addContainerGap(45, Short.MAX_VALUE)
                .addComponent(settingsIcon)
                .addGap(57, 57, 57))
            .addGroup(jPanelSettingsLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(settingsTitle)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanelSettingsLayout.setVerticalGroup(
            jPanelSettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelSettingsLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(settingsIcon)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(settingsTitle)
                .addContainerGap(33, Short.MAX_VALUE))
        );

        jPanelBG.add(jPanelSettings, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 440, 150, -1));

        jPanelClasses.setBackground(new java.awt.Color(228, 226, 226));
        jPanelClasses.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanelClassesMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanelClassesMouseExited(evt);
            }
        });

        classesIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/schoolmanagementsystem/images/icons8_list_48px.png"))); // NOI18N

        classesTitle.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        classesTitle.setText("Classes");
        classesTitle.setToolTipText("");

        javax.swing.GroupLayout jPanelClassesLayout = new javax.swing.GroupLayout(jPanelClasses);
        jPanelClasses.setLayout(jPanelClassesLayout);
        jPanelClassesLayout.setHorizontalGroup(
            jPanelClassesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelClassesLayout.createSequentialGroup()
                .addContainerGap(55, Short.MAX_VALUE)
                .addGroup(jPanelClassesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(classesTitle)
                    .addComponent(classesIcon))
                .addGap(45, 45, 45))
        );
        jPanelClassesLayout.setVerticalGroup(
            jPanelClassesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelClassesLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(classesIcon)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(classesTitle)
                .addContainerGap(33, Short.MAX_VALUE))
        );

        jPanelBG.add(jPanelClasses, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 440, 160, -1));

        jPanelUpdate.setBackground(new java.awt.Color(228, 226, 226));
        jPanelUpdate.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanelUpdateMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanelUpdateMouseExited(evt);
            }
        });

        updateIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/schoolmanagementsystem/images/icons8_downloading_updates_48px_1.png"))); // NOI18N

        updateTitle.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        updateTitle.setText("Update");
        updateTitle.setToolTipText("");

        javax.swing.GroupLayout jPanelUpdateLayout = new javax.swing.GroupLayout(jPanelUpdate);
        jPanelUpdate.setLayout(jPanelUpdateLayout);
        jPanelUpdateLayout.setHorizontalGroup(
            jPanelUpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelUpdateLayout.createSequentialGroup()
                .addContainerGap(43, Short.MAX_VALUE)
                .addGroup(jPanelUpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(updateTitle)
                    .addComponent(updateIcon))
                .addGap(45, 45, 45))
        );
        jPanelUpdateLayout.setVerticalGroup(
            jPanelUpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelUpdateLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(updateIcon)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(updateTitle)
                .addContainerGap(33, Short.MAX_VALUE))
        );

        jPanelBG.add(jPanelUpdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 440, 150, -1));

        getContentPane().add(jPanelBG, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 910, 800));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jpanelHomeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jpanelHomeMouseEntered
        setColor(jpanelHome);
    }//GEN-LAST:event_jpanelHomeMouseEntered

    private void jpanelHomeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jpanelHomeMouseExited
        resetColor(jpanelHome);
    }//GEN-LAST:event_jpanelHomeMouseExited

    private void jPanelStudentMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanelStudentMouseEntered
        setColor(jPanelStudent);
    }//GEN-LAST:event_jPanelStudentMouseEntered

    private void jPanelStudentMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanelStudentMouseExited
        resetColor(jPanelStudent);
    }//GEN-LAST:event_jPanelStudentMouseExited

    private void jPanelTimeTableMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanelTimeTableMouseEntered
        setColor(jPanelTimeTable);
    }//GEN-LAST:event_jPanelTimeTableMouseEntered

    private void jPanelTimeTableMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanelTimeTableMouseExited
        resetColor(jPanelTimeTable);
    }//GEN-LAST:event_jPanelTimeTableMouseExited

    private void jPanelSettingsMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanelSettingsMouseEntered
        setColor(jPanelSettings);
    }//GEN-LAST:event_jPanelSettingsMouseEntered

    private void jPanelSettingsMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanelSettingsMouseExited
        resetColor(jPanelSettings);
    }//GEN-LAST:event_jPanelSettingsMouseExited

    private void jPanelClassesMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanelClassesMouseEntered
        setColor(jPanelClasses);
    }//GEN-LAST:event_jPanelClassesMouseEntered

    private void jPanelClassesMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanelClassesMouseExited
        resetColor(jPanelClasses);
    }//GEN-LAST:event_jPanelClassesMouseExited

    private void jPanelUpdateMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanelUpdateMouseEntered
        setColor(jPanelUpdate);
    }//GEN-LAST:event_jPanelUpdateMouseEntered

    private void jPanelUpdateMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanelUpdateMouseExited
        resetColor(jPanelUpdate);
    }//GEN-LAST:event_jPanelUpdateMouseExited

    private void jpanelHomeMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jpanelHomeMousePressed
        new Login_info().show();
        
    }//GEN-LAST:event_jpanelHomeMousePressed

    private void jPanelStudentMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanelStudentMousePressed
       new Settings_info().show();
    }//GEN-LAST:event_jPanelStudentMousePressed

    //Jpanel hover color change
    public void setColor(JPanel panel){
        panel.setBackground(new java.awt.Color(250,246,194));    
    }
    //Jpanel hover color reset
    public void resetColor(JPanel panel){
        panel.setBackground(new java.awt.Color(228,226,226));
    }
    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Home().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel classesIcon;
    private javax.swing.JLabel classesTitle;
    private javax.swing.JLabel homeIcon;
    private javax.swing.JLabel homeTitle;
    private javax.swing.JPanel jPanelBG;
    private javax.swing.JPanel jPanelClasses;
    private javax.swing.JPanel jPanelHeader;
    private javax.swing.JPanel jPanelSettings;
    private javax.swing.JPanel jPanelStudent;
    private javax.swing.JPanel jPanelTimeTable;
    private javax.swing.JPanel jPanelUpdate;
    private javax.swing.JPanel jpanelHome;
    private javax.swing.JLabel logo;
    private javax.swing.JLabel settingsIcon;
    private javax.swing.JLabel settingsTitle;
    private javax.swing.JLabel studentTitle;
    private javax.swing.JLabel tagline;
    private javax.swing.JLabel timeTableIcon;
    private javax.swing.JLabel timeTableTitle;
    private javax.swing.JLabel updateIcon;
    private javax.swing.JLabel updateTitle;
    private javax.swing.JLabel userIcon;
    // End of variables declaration//GEN-END:variables
}
